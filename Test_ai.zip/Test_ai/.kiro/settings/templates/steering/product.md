# Product Overview

[Brief description of what this product does and who it serves]

## Core Capabilities

[3-5 key capabilities, not exhaustive features]

## Target Use Cases

[Primary scenarios this product addresses]

## Value Proposition

[What makes this product unique or valuable]

---
_Focus on patterns and purpose, not exhaustive feature lists_
