"""
Test suite for Numpy Data Visualizer
"""
